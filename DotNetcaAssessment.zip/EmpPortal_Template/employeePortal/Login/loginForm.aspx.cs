﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empPortal.business;
using log4net;
using System.Web.Security;
using System.Configuration;


namespace empPortal.Login
{
    public partial class loginForm : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessEmployeeDetails businessObjEmp = new businessEmployeeDetails(); 
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        // Authenticate User
        protected void LoginControl_Authenticate(object sender, AuthenticateEventArgs e)
        {
            try
            {
                    //Please do the CaseStudy Implementation here for Authentication.
                 CustomMembershipProvider objProvider =new CustomMembershipProvider();
                 if (objProvider.ValidateUser(LoginControl.UserName, LoginControl.Password))
                 {
                     CustomRoleProvider objRoleProvider = new CustomRoleProvider();
                     string[] roles = new string[2];
                     roles = objRoleProvider.GetRolesForUser(LoginControl.UserName);
                     SetFormAuthenticationTicket(LoginControl.UserName, roles[0]);                     
                     //Please do the CaseStudy Implementation here for Authorization.
                     Session["UserRole"] = roles[0];
                     Session["UserName"] = LoginControl.UserName;
                     if (roles[0].Equals("admin"))
                     {
                         Response.Redirect("~/Admin/addEmployee.aspx", false);
                     }
                     else if (roles[0].Equals("user"))
                     {
                         Response.Redirect("~/User/userRegulationReport.aspx?UserRole=" + roles[0] + "&value="+LoginControl.UserName, false);
                     }
                     else
                     {
                     }
                     
                 }      
               
            }
            catch (Exception ex)
            {
                logger.Error("Exception occurred during Authentication for the user " + ex.Message);
                logger.Error("Exception occurred during Authentication for the user " + Server.GetLastError());
                Session["CurrentError"] = "Error occured during Authentication for the user " + LoginControl.UserName.ToString();
                Response.Redirect("~/ErrorPage/customErrorPage.aspx",false);
            }
        }


        public void SetFormAuthenticationTicket(string userName, string roleName)
        {
            FormsAuthentication.Initialize();
            FormsAuthenticationTicket Authticket = new FormsAuthenticationTicket(1,
                                                    userName,
                                                    DateTime.Now,
                                                    DateTime.Now.AddMinutes(30),
                                                    false, // Do not remember me
                                                    roleName,
                                                    FormsAuthentication.FormsCookiePath);

            string hash = FormsAuthentication.Encrypt(Authticket);

            HttpCookie Authcookie = new HttpCookie(FormsAuthentication.FormsCookieName, hash);
            if (Authticket.IsPersistent) Authcookie.Expires = Authticket.Expiration;
            Response.Cookies.Add(Authcookie);
        }

    }
}