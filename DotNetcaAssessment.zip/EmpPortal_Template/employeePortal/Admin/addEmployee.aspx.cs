﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empPortal.business;
using System.Data;
using log4net;
using System.Configuration;
using System.Web.Security;
using System.Security.Principal;
using System.Threading;

namespace empPortal
{
    public partial class addEmployee : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"

        businessEmployeeDetails businessObj = new businessEmployeeDetails();
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #endregion

        // Variable Declaration
        #region "Variable Declaration"
        DataSet employeeDataSet, departmentDataSet;
        int getRowCount;
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
               if (!Page.IsPostBack)
                {
                    BindEmployeeDetails();
                    messageLabel.Text = String.Empty;
                    BindDepartmentDetails();
                }
                this.firstNameTextBox.Focus();
           
        }

        // Casestudy Implementation here
        public override void VerifyRenderingInServerForm(Control control)
        {
            //base.VerifyRenderingInServerForm(control);
        }

        // Fetch Employee data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindEmployeeDetails()
        {
            logger.Debug("Binding the Employee details to the GridView ");

            employeeDataSet = new DataSet();
            employeeDataSet = businessObj.GetEmployeeDetails();
            EmployeeGridView.DataSource = employeeDataSet;
            EmployeeGridView.DataBind();
            logger.Debug("Employee details mapped to the dropdownlist successfully.");

        }
        #endregion

        // Fetch DEpartment data from DB and display in the grid
        #region "Bind Department Details"
        public void BindDepartmentDetails()
        {
            //Please do the CaseStudy Implementation here

            logger.Debug("Binding the Department details to the GridView ");

            departmentDataSet = new DataSet();
            departmentDataSet = businessObj.GetDepartmentDetails();
            departmentDropdownList.DataSource = departmentDataSet;
            departmentDropdownList.DataTextField = "DeptDescription";
            departmentDropdownList.DataValueField = "DeptId";
            departmentDropdownList.DataBind();
            departmentDropdownList.Items.Insert(0, "<--Select-->");
            logger.Debug("Department details mapped to the dropdownlist successfully.");
        }
        #endregion

        // Update grid changes to DB and display the changes
        protected void EmployeeGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            logger.Debug(" Updating the Employee details");

            GridViewRow _row = EmployeeGridView.Rows[e.RowIndex];
            TextBox firstNameTextBox = (TextBox)_row.FindControl("firstNameTextBox");
            TextBox lastNameTextBox = (TextBox)_row.FindControl("lastNameTextBox");
            TextBox dateOfBirthTextBox = (TextBox)_row.FindControl("dateOfBirthTextBox");
            TextBox emailTextBox = (TextBox)_row.FindControl("emailTextBox");
            TextBox phoneTextBox = (TextBox)_row.FindControl("phoneTextBox");
            Label lblEmpId = (Label)_row.FindControl("lblEmpId");
            if (businessEmployeeDetails.ValidateAge(Convert.ToDateTime(dateOfBirthTextBox.Text), System.DateTime.Today))
            {
                getRowCount = businessObj.UpdateEmployeeDetails(lblEmpId.Text.Trim(), firstNameTextBox.Text.Trim(), lastNameTextBox.Text.Trim(), dateOfBirthTextBox.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim());
                EmployeeGridView.EditIndex = -1;
                BindEmployeeDetails();
                messageLabel.Text = "Employee Details updated successfully!...";
                logger.Debug(" Employee details updated successfully.No of records impacted are " + getRowCount.ToString());
            }
            else
            {
                messageLabel.Text = "Employee Age should be greater than 24. Please check and proceed !....";
                logger.Warn(" Employee age should be greater than 24. Update failed. Please check the data and retry.");
            }

        }

        // Cancel grid changes
        protected void EmployeeGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            EmployeeGridView.EditIndex = -1;
            BindEmployeeDetails();
            messageLabel.Text = String.Empty;
        }


        // Casestudy Implementation here

        // Delete the selected row from the grid and update DB
        protected void EmployeeGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            logger.Debug("Deleting the Employee details");

            GridViewRow _row = EmployeeGridView.Rows[e.RowIndex];
            Label lblEmpId = (Label)_row.FindControl("lblEmpId");

            getRowCount = businessObj.DeleteEmployeeDetails(lblEmpId.Text.Trim());
            EmployeeGridView.EditIndex = -1;
            BindEmployeeDetails();
            messageLabel.Text = "Employee Details deleted successfully!...";

        }

        // Display the grid with editable fields
        protected void EmployeeGridView_RowEditing(object sender, GridViewEditEventArgs e)
        {
            logger.Debug("Editing the Employee details...");
            EmployeeGridView.EditIndex = e.NewEditIndex;
            BindEmployeeDetails();
            messageLabel.Text = String.Empty;

        }

        // Update DB with the new Employee details and display the grid
        protected void addEmployeeButton_Click(object sender, EventArgs e)
        {
            logger.Debug("Adding the Employee details....");

            
            //Please do the CaseStudy Implementation here

            if (businessEmployeeDetails.ValidateAge(Convert.ToDateTime(dateOfBirthTextBox.Text.Trim()), System.DateTime.Today))
            {
                getRowCount = businessObj.AddEmployeeDetails(departmentDropdownList.Text, firstNameTextBox.Text.Trim(), lastNameTextBox.Text.Trim(), dateOfBirthTextBox.Text.Trim(), emailTextBox.Text.Trim(), phoneTextBox.Text.Trim());
                EmployeeGridView.EditIndex = -1;
                EmployeeGridView.ShowFooter = false;
                BindEmployeeDetails();
                firstNameTextBox.Text = String.Empty;
                lastNameTextBox.Text = String.Empty;
                dateOfBirthTextBox.Text = String.Empty;
                emailTextBox.Text = String.Empty;
                phoneTextBox.Text = String.Empty;
                messageLabel.Text = "Employee Details added successfully!...";
                logger.Debug("Employee details added successfully....No of records impacted are " + getRowCount.ToString());
            }
            else
            {
                messageLabel.Text = "Employee Age should be greater than 24. Please check and proceed.";
                logger.Warn(" Employee age should be greater than 24. Update failed. Please check the data and retry.");
            }

        }

    }
}
