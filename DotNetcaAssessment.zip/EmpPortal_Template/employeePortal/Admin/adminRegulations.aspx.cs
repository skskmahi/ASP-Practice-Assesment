﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empPortal.business;
using System.Data;
using log4net;
using System.Configuration;

namespace empPortal.Admin
{
    public partial class adminRegulations : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessEmployeeDetails businessEmployeeObj = new businessEmployeeDetails();
        businessRegulationDetails businessRegulationObj = new businessRegulationDetails();
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #endregion
        
        // Variable Declaration
        #region "Variable Declaration"
        DataSet regulationDataSet;
        DataSet departmentDataSet;
        int getRowCount;
        #endregion

        // Page load
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindData();
                messageLabel.Text = String.Empty;
                BindDepartmentDetails();
            }
            this.regulationTypeDropdownList.Focus();
        }

        // Fetch Regulation data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindData()
        {
            logger.Debug("Binding the Regulation details to the GridView ");
           
                //regulationDataSet = new DataSet();
            regulationDataSet = businessRegulationObj.GetRegulationDetails();
            RegulationGridView.DataSource = regulationDataSet;
            RegulationGridView.DataBind();
            logger.Debug("Regulation details mapped to the Grid successfully.");
           

        }
        #endregion

        // Fetch department data from DB and display in the grid
        #region "Bind Department Details"
        public void BindDepartmentDetails()
        {
            //Please do the CaseStudy Implementation here
        }
        #endregion

        // Update DB with the new Regulation details and display the grid
        protected void addRegulationButton_Click(object sender, EventArgs e)
        {
            
            logger.Debug("Adding the Regulation details....");
            getRowCount = businessRegulationObj.AddRegulationDetails(departmentDropdownList.Text.Trim(), regulationTypeDropdownList.Text.Trim(), regulationDetailsTextBox.Text.Trim(), creationDateTextBox.Text.Trim());
            RegulationGridView.EditIndex = -1;
            RegulationGridView.ShowFooter = false;
            BindData();
            regulationDetailsTextBox.Text = String.Empty;
            creationDateTextBox.Text = String.Empty;
            messageLabel.Text = "Regulation Details added successfully!...";
            logger.Debug("Regulation details added successfully....No of records impacted are " + getRowCount.ToString());
            
        }

        //Casestudy Implementation 
        protected void RegulationGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            logger.Debug("Deleting the Regulation details");

            GridViewRow _row = RegulationGridView.Rows[e.RowIndex];
            Label lblComplianceID = (Label)_row.FindControl("lblComplianceId");

            getRowCount = businessRegulationObj.DeleteRegulationDetails(lblComplianceID.Text.Trim());
            RegulationGridView.EditIndex = -1;
            BindData();
            messageLabel.Text = "Employee Details deleted successfully!...";
        }

    
    }
}