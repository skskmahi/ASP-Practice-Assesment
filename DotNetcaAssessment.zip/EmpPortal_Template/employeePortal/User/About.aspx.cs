﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Threading;
using System.Globalization;


namespace empPortal.User
{
    public partial class About : System.Web.UI.Page
    {

        void Page_PreInit(Object sender, EventArgs e)
        {
            this.MasterPageFile = "~/User/User.Master";
        }


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected override void InitializeCulture()
        {
            string language = Request.Form["ctl00$MainContent$languageDropdownlist"];
            string languageId = "";

            if (!string.IsNullOrEmpty(language))
            {
                // Please do the Casestudy Implementation here.
                languageId = "en-us";
                Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(languageId);
                Thread.CurrentThread.CurrentUICulture = new CultureInfo(languageId);
            }
                     base.InitializeCulture();
            }


        }
    
}