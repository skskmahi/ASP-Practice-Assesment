﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using empPortal.business;
using log4net;
using System.Configuration;

namespace empPortal.User
{
    public partial class userRegulationReport : System.Web.UI.Page
    {
        // Object initialization
        #region "Object Initialization"
        businessRegulationDetails businessRegulationObj = new businessRegulationDetails();
        private static ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static string userName, roleName;


        #endregion

        // Page load    
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindData();
            }
        }

        // Fetch Regulation data from DB and display in the grid
        #region "Bind Grid Details"
        public void BindData()
        {
            logger.Debug("Binding the Regulation Status details to the GridView ");
            
            // Casestudy Implementation here
            roleName = Session["UserRole"].ToString();
            userName = Request.QueryString["value"].ToString(); // UserName has to be passed to this page via Query String value after proper authentication.
            DataSet statusDataSet = businessRegulationObj.GetRegulationsByUser(userName, roleName);
            RegulationGridView.DataSource = statusDataSet;
            RegulationGridView.DataBind();
            logger.Debug("Regulation Status details mapped to the Grid successfully.");
        }
        #endregion

         public SortDirection dir
        {
            get
            {
                if (ViewState["dirState"] == null)
                {
                    ViewState["dirState"] = SortDirection.Ascending;
                }
                return (SortDirection)ViewState["dirState"];
            }
            set
            {
                ViewState["dirState"] = value;
            }
        }

        protected void RegulationGridView_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortingDirection = string.Empty;
            if (dir == SortDirection.Ascending)
            {
                dir = SortDirection.Descending;
                sortingDirection = "Desc";
            }
            else
            {
                dir = SortDirection.Ascending;
                sortingDirection = "Asc";
            }

            DataSet statusDataSet = businessRegulationObj.GetRegulationsByUser(userName, roleName);
            DataView sortedView = new DataView(statusDataSet.Tables[0]);
            sortedView.Sort = e.SortExpression + " " + sortingDirection;
            RegulationGridView.DataSource = sortedView;
            RegulationGridView.DataBind();
        }

         //Please do the CaseStudy Implementation here. 
        protected void RegulationGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

            RegulationGridView.PageIndex = e.NewPageIndex;
            BindData();

        }
        
    }
}