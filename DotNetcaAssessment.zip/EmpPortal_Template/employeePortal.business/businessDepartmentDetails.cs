﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using empPortal.data;


namespace empPortal.business
{
    public class businessDepartmentDetails
    {
        #region "Variable Declaration"

        DataSet departmentDataSet = null;
        string getQuery = string.Empty;

        dalDepartmentDetails dalDepartmentObj = new dalDepartmentDetails();

        #endregion

        #region "Object Initialization"
        int rowCount = 0;
        #endregion

        #region "Get Department Details"
        public void GetDepartmentDetails()
        {
            //Please do the CaseStudy Implementation here
        }
        #endregion
   }
}
