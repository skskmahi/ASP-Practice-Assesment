﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using empPortal.data;

namespace empPortal.business
{
    public class businessRegulationDetails
    {
        #region "Variable Declaration"
        string getQuery = string.Empty;
        int rowCount = 0;
        dalDepartmentDetails dalDepartmentObj = new dalDepartmentDetails();
        dalRegulationDetails dalRegulationObj = new dalRegulationDetails();
        #endregion

        #region "Get Drop Downlist Bind Details"
        public void GetDepartmentDetails()
        {
            // Please do the Casestudy Implementation here.

        }
        #endregion

        #region "Get  Details"
        public DataSet GetRegulationDetails()
        {
            DataSet regulationDataSet = dalRegulationObj.GetRegulationDetails();
            return regulationDataSet;

        }
        #endregion

        #region "Get Regulation Details By User"
        public DataSet GetRegulationsByUser(string EmpName, string EmpRole)
        {
            DataSet regulationDataSet = dalRegulationObj.GetRegulationsByUser(EmpName, EmpRole);
            return regulationDataSet;
        }

        #endregion

        #region "Add Details"
        public int AddRegulationDetails(string DeptId, string ComplianceType, string Details, string CreationDate)
        {
            try
            {
                rowCount = dalRegulationObj.AddRegulationDetails(DeptId, ComplianceType, Details, CreationDate);
                return rowCount;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion
        
        #region "Delete Regulation Details"
        public int DeleteRegulationDetails(string regulationId)
        {
            try
            {
                rowCount = dalRegulationObj.DeleteRegulationDetails(regulationId);
                return rowCount;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

    }
}
