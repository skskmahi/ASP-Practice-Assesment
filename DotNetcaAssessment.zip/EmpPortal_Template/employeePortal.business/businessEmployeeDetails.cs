﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using empPortal.data;
using System.Data;


namespace empPortal.business
{
   public class businessEmployeeDetails
    {
        #region "Variable Declaration"
            string getQuery = string.Empty;
            int rowCount = 0;
            dalDepartmentDetails dalDepartmentObj = new dalDepartmentDetails();
            dalEmployeeDetails dalEmployeeObj = new dalEmployeeDetails();
        #endregion
             
        #region "Get Drop Downlist Bind Details"
        public DataSet GetDepartmentDetails()
        {
            // Please do the Casestudy Implementation here.

            DataSet dptDataSet = dalDepartmentObj.GetDepartmentDetails();
            return dptDataSet;
        }
        #endregion

        #region "Get Employee Details"
        public DataSet GetEmployeeDetails()
        {
            DataSet employeeDataSet = dalEmployeeObj.GetEmpDetails();
            return employeeDataSet;

        }

        #endregion

        #region "Add Details"
        public int AddEmployeeDetails(string DeptId, string FirstName, string LastName, string DateOfBirth, string Email, string PhoneNo)
        {
            try
            {
                rowCount = dalEmployeeObj.AddEmployeeDetails(DeptId, FirstName, LastName, DateOfBirth, Email, PhoneNo);
                return rowCount;
            }
            catch (Exception)
            {
               
                throw;
            }
        }
        #endregion

        #region "Update Details"
        public int UpdateEmployeeDetails(string EmpId, string FirstName, string LastName, string DateOfBirth, string Email, string PhoneNo)
        {
            try
            {
                rowCount = dalEmployeeObj.UpdateEmployeeDetails(EmpId, FirstName, LastName, DateOfBirth, Email, PhoneNo);
                return rowCount;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        #endregion

        #region "Delete Details"
        public int DeleteEmployeeDetails(string EmpId)
        {
            try
            {
                rowCount = dalEmployeeObj.DeleteEmployeeDetails(EmpId);
                return rowCount;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        #endregion

        # region "Validate Age"
        public static bool ValidateAge(DateTime dateOfBirth, DateTime asOfDate)
        {
            int age = asOfDate.Year - dateOfBirth.Year;
            if (asOfDate.Month < dateOfBirth.Month || (asOfDate.Month == dateOfBirth.Month && asOfDate.Day < dateOfBirth.Day))
            age--;

            if (age > 24) { return true; } else { return false; }
            
        }
        # endregion 
    }
}
