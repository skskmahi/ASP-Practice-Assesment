﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using empPortal.common;
using System.Data.SqlClient;

namespace empPortal.data
{
    public class dalRegulationDetails
    {
        #region "Get Regulation Details"
        public  DataSet GetRegulationDetails()
        {
            try
            {
                DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetRegulationDetails");
                return ds;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        #region "Get Regulation Details Based on Employee name and role"
        public DataSet GetRegulationsByUser(string EmpName, string EmpRole)
        {
            try
            {

                SqlParameter[] sqlParams = new SqlParameter[2];
                sqlParams[0] = new SqlParameter("@empName", EmpName);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;
                sqlParams[1] = new SqlParameter("@empRole", EmpRole);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;

                DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetRegulationDetailsByUser", sqlParams);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "Add Regulation Details"
        public int AddRegulationDetails(string DeptId, string ComplianceType, string Details, string CreationDate)
        {

            try
            {
                SqlParameter[] sqlParams = new SqlParameter[4];
                sqlParams[0] = new SqlParameter("@deptId", DeptId);
                sqlParams[0].SqlDbType = SqlDbType.Int;
                sqlParams[1] = new SqlParameter("@regulationType", ComplianceType);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;
                sqlParams[2] = new SqlParameter("@regulationDetails", Details);
                sqlParams[2].SqlDbType = SqlDbType.VarChar;
                sqlParams[3] = new SqlParameter("@creationDate", CreationDate);
                sqlParams[3].SqlDbType = SqlDbType.Date;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddRegulationDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion
        
        #region "Delete Regulation Details"
        public int DeleteRegulationDetails(string regulationId)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@RegulationId", regulationId);
                sqlParams[0].SqlDbType = SqlDbType.Int;
                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "DeleteRegulationDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

    }
}
