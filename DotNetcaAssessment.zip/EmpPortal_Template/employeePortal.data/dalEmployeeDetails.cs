﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Data.SqlClient;
using empPortal.common;

namespace empPortal.data
{
    public class dalEmployeeDetails
    {
        #region "Get Details"
        public DataSet GetEmpDetails()
        {
            try
            {
                DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetEmployeeDetails");
                return ds;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        #region "Add Details"
        public int AddEmployeeDetails(string DeptId, string FirstName, string LastName, string DateOfBirth, string Email, string PhoneNo)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[6];
                sqlParams[0] = new SqlParameter("@deptId", DeptId);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;
                sqlParams[1] = new SqlParameter("@firstName", FirstName);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;
                sqlParams[2] = new SqlParameter("@lastName", LastName);
                sqlParams[2].SqlDbType = SqlDbType.VarChar;
                sqlParams[3] = new SqlParameter("@dateOfBirth", DateOfBirth);
                sqlParams[3].SqlDbType = SqlDbType.Date;
                sqlParams[4] = new SqlParameter("@Email", Email);
                sqlParams[4].SqlDbType = SqlDbType.VarChar;
                sqlParams[5] = new SqlParameter("@phoneNo", PhoneNo);
                sqlParams[5].SqlDbType = SqlDbType.VarChar;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "AddEmployeeDetails", sqlParams);
                return rowCount;
         
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region "Update Details"
        public int UpdateEmployeeDetails(string EmpId, string FirstName, string LastName, string DateOfBirth, string Email, string PhoneNo)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[6];
                sqlParams[0] = new SqlParameter("@EmpId", EmpId);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;
                sqlParams[1] = new SqlParameter("@firstName", FirstName);
                sqlParams[1].SqlDbType = SqlDbType.VarChar;
                sqlParams[2] = new SqlParameter("@lastName", LastName);
                sqlParams[2].SqlDbType = SqlDbType.VarChar;
                sqlParams[3] = new SqlParameter("@dateOfBirth", DateOfBirth);
                sqlParams[3].SqlDbType = SqlDbType.Date;
                sqlParams[4] = new SqlParameter("@email", Email);
                sqlParams[4].SqlDbType = SqlDbType.VarChar;
                sqlParams[5] = new SqlParameter("@phoneNo", PhoneNo);
                sqlParams[5].SqlDbType = SqlDbType.VarChar;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "UpdateEmployeeDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region "Delete Details"
        public int DeleteEmployeeDetails(string EmpId)
        {
            try
            {
                SqlParameter[] sqlParams = new SqlParameter[1];
                sqlParams[0] = new SqlParameter("@EmpId", EmpId);
                sqlParams[0].SqlDbType = SqlDbType.VarChar;

                int rowCount = commonFunction.ExecuteNonQuery(CommandType.StoredProcedure, "DeleteEmployeeDetails", sqlParams);
                return rowCount;

            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

    }
}
