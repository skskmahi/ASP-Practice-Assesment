﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using empPortal.common;
using System.Data.SqlClient;

namespace empPortal.data
{
  public class dalDepartmentDetails
  {
      #region "Get Department Details"
      public DataSet GetDepartmentDetails()
      {
          try
          {
              DataSet ds = commonFunction.ExecuteDataset(CommandType.StoredProcedure, "GetDepartmentDetails");
              return ds;
          }
          catch (Exception ex)
          {

              throw ex;
          }
      }
      #endregion
  }
}
