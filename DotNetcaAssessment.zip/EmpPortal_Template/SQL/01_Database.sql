USE master
IF EXISTS(select * from sys.databases where name='Employee')
DROP DATABASE Employee
go 
Create Database Employee
go