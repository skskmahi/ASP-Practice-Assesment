USE [Employee]
GO

/****** Object:  Table [dbo].[Department]    Script Date: 10/22/2013 12:12:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[Department](
	[DeptId] [int] IDENTITY(1,1) NOT NULL,
	[DeptName] [varchar](25) NULL,
	[DeptDescription] [varchar](150) NULL,
PRIMARY KEY CLUSTERED 
(
	[DeptId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

USE [Employee]
GO

/****** Object:  Table [dbo].[Employees]    Script Date: 10/22/2013 12:12:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[Employees](
	[EmpId] [int] IDENTITY(1,10) NOT NULL,
	[DeptId] [int] NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NOT NULL,
	[DateOfBirth] [date] NULL,
	[Email] [varchar](50) NULL,
	[PhoneNo] [varchar](50) NULL,
 CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED 
(
	[EmpId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [uk_empName] UNIQUE NONCLUSTERED 
(
	[FirstName] ASC,
	[LastName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

USE [Employee]
GO

/****** Object:  Table [dbo].[EmpRoles]    Script Date: 10/22/2013 12:12:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[EmpRoles](
	[UserId] [int] NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[Password] [varchar](50) NOT NULL,
	[RoleName] [varchar](20) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

USE [Employee]
GO

/****** Object:  Table [dbo].[Regulation]    Script Date: 10/22/2013 12:12:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Regulation](
	[RegulationId] [int] IDENTITY(1,1) NOT NULL,
	[RegulationType] [varchar](50) NOT NULL,
	[Details] [varchar](500) NOT NULL,
	[CreationDate] [date] NOT NULL,
	[DeptId] [int] NOT NULL,
 CONSTRAINT [PK_Compliance] PRIMARY KEY CLUSTERED 
(
	[RegulationId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

USE [Employee]
GO

/****** Object:  Table [dbo].[RegulationReport]    Script Date: 10/22/2013 12:12:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[RegulationReport](
	[ReportId] [int] IDENTITY(1,1) NOT NULL,
	[RegulationId] [int] NOT NULL,
	[EmpId] [int] NOT NULL,
	[Comments] [varchar](50) NOT NULL,
	[StatusCreationDate] [date] NOT NULL,
	[DeptId] [int] NOT NULL,
	[Status] [varchar](20) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Employees]  WITH CHECK ADD  CONSTRAINT [FK_Employees_Department] FOREIGN KEY([DeptId])
REFERENCES [dbo].[Department] ([DeptId])
GO

ALTER TABLE [dbo].[Employees] CHECK CONSTRAINT [FK_Employees_Department]
GO

ALTER TABLE [dbo].[EmpRoles]  WITH CHECK ADD  CONSTRAINT [FK_UserInRoles_Employees] FOREIGN KEY([UserId])
REFERENCES [dbo].[Employees] ([EmpId])
GO

ALTER TABLE [dbo].[EmpRoles] CHECK CONSTRAINT [FK_UserInRoles_Employees]
GO

ALTER TABLE [dbo].[RegulationReport]  WITH CHECK ADD  CONSTRAINT [FK_StatusReport_Department] FOREIGN KEY([DeptId])
REFERENCES [dbo].[Department] ([DeptId])
GO

ALTER TABLE [dbo].[RegulationReport] CHECK CONSTRAINT [FK_StatusReport_Department]
GO

ALTER TABLE [dbo].[RegulationReport]  WITH CHECK ADD  CONSTRAINT [FK_StatusReport_Employees] FOREIGN KEY([EmpId])
REFERENCES [dbo].[Employees] ([EmpId])
GO

ALTER TABLE [dbo].[RegulationReport] CHECK CONSTRAINT [FK_StatusReport_Employees]
GO

ALTER TABLE [dbo].[RegulationReport]  WITH CHECK ADD  CONSTRAINT [FK_StatusReport_Regulation] FOREIGN KEY([RegulationId])
REFERENCES [dbo].[Regulation] ([RegulationId])
GO

ALTER TABLE [dbo].[RegulationReport] CHECK CONSTRAINT [FK_StatusReport_Regulation]
GO


USE [Employee]
GO

/****** Object:  StoredProcedure [dbo].[UpdateUserPassword]    Script Date: 10/31/2013 14:55:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		COGNIZANT
-- Create date: 05/26/2013
-- Description:	Get the Employee details and authenticate the user against Employee Db.
-- =============================================
CREATE PROCEDURE [dbo].[UpdateUserPassword] 
@firstName varchar(50),
@lastName varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @empId   int
    DECLARE @userRole varchar(10)
    SET @userRole = 'user'
        DECLARE @defaultPassword varchar(10)
    SET @defaultPassword = 'default'
	Select @empId = EmpId from Employees where FirstName=@firstName and LastName=@lastName;
	insert into EmpRoles (UserId,UserName,Password,RoleName) values (@empId,@firstName,@defaultPassword, @userRole);
END

GO


/****** Object:  StoredProcedure [dbo].[AddEmployeeDetails]    Script Date: 10/22/2013 12:16:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================  
-- Author:  COGNIZANT  
-- Create date: 05/26/2013  
-- Description: Get the Employee details and authenticate the user against Employee Db.  
-- =============================================  
CREATE PROCEDURE [dbo].[AddEmployeeDetails]   
@deptId int,   
@firstName varchar(50),  
@lastName varchar(50),  
@dateOfBirth date,  
@Email varchar(50),  
@phoneNo varchar(50)  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
 insert into Employees (DeptId,FirstName,LastName,DateOfBirth,Email,PhoneNo)   
 values (@deptId,@firstName, @lastName, @dateOfBirth,  @Email, @phoneNo)  
 
 exec dbo.UpdateUserPassword @firstName,@lastName
 
END  
GO

/****** Object:  StoredProcedure [dbo].[AddRegulationDetails]    Script Date: 10/22/2013 12:16:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		COGNIZANT
-- Create date: 05/26/2013
-- Description:	Add Regulation details for each department into Employee Db.
-- =============================================
CREATE PROCEDURE [dbo].[AddRegulationDetails] 
@deptId int,
@regulationType varchar(50),
@regulationDetails varchar(500),
@creationDate date
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   insert into Regulation (DeptId,RegulationType,Details,CreationDate) values (@deptId,@regulationType,@regulationDetails,@creationDate);
END

GO

/****** Object:  StoredProcedure [dbo].[DeleteEmployeeDetails]    Script Date: 10/22/2013 12:16:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		COGNIZANT
-- Create date: 05/26/2013
-- Description:	Delete Employee details in Employee Db.
-- =============================================
CREATE PROCEDURE [dbo].[DeleteEmployeeDetails] 
@EmpId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    delete from EmpRoles where UserId=@EmpId;
	delete from Employees where EmpId=@EmpId;
END

GO

/****** Object:  StoredProcedure [dbo].[DeleteRegulationDetails]    Script Date: 10/22/2013 12:16:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================  
-- Author:  COGNIZANT  
-- Create date: 05/26/2013  
-- Description: Delete Employee details in Employee Db.  
-- =============================================  
CREATE PROCEDURE [dbo].[DeleteRegulationDetails]   
@RegulationId int  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
    delete from dbo.RegulationReport where RegulationId=@RegulationId;  
	delete from dbo.Regulation where RegulationId=@RegulationId;  
END  
GO

/****** Object:  StoredProcedure [dbo].[GetDepartmentDetails]    Script Date: 10/22/2013 12:16:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[GetDepartmentDetails]
AS
SELECT 
	DeptId,
	DeptName,
	DeptDescription 
FROM Department
GO

/****** Object:  StoredProcedure [dbo].[GetEmployeeDetails]    Script Date: 10/22/2013 12:16:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		COGNIZANT
-- Create date: 05/26/2013
-- Description:	Get the Employee details from Employee Db.
-- =============================================
CREATE PROCEDURE [dbo].[GetEmployeeDetails] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select emp.EmpId as EmpId,dept.DeptName as DeptName,emp.FirstName as FirstName,emp.LastName as LastName,emp.DateOfBirth as DateOfBirth, emp.Email as Email,emp.PhoneNo as PhoneNo from Employees emp, Department dept where emp.DeptId = dept.DeptId

END

GO

/****** Object:  StoredProcedure [dbo].[GetRegulationDetails]    Script Date: 10/22/2013 12:16:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		COGNIZANT
-- Create date: 05/26/2013
-- Description:	Get Regulation details from Employee Db.
-- =============================================
CREATE PROCEDURE [dbo].[GetRegulationDetails] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    select reg.RegulationId as RegulationId,dept.DeptName as DeptName,reg.RegulationType as RegulationType,reg.Details as Details,reg.CreationDate as CreationDate from Regulation reg, Department dept where reg.DeptId = dept.DeptId
END

GO

/****** Object:  StoredProcedure [dbo].[GetRegulationDetailsByUser]    Script Date: 10/22/2013 12:16:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================  
-- Author:  COGNIZANT  
-- Create date: 05/26/2013  
-- Description: Get Regulation details from Employee Db.  
-- =============================================  
CREATE PROCEDURE [dbo].[GetRegulationDetailsByUser]   
@empName varchar(50),
@empRole varchar(10)  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
--   select reg.RegulationId as RegulationId,reg.RegulationType as RegulationType, reg.CreationDate as CreationDate,reg.DeptId as DeptId,depart.DeptName as DepartmentName,reg.Details as Details from Regulation reg, Department depart, Employees emp where reg
--.DeptId = depart.DeptId and emp.DeptId = depart.DeptId and emp.EmpId=@EmpId;  
   select reg.RegulationId as RegulationId,reg.RegulationType as RegulationType, reg.CreationDate as CreationDate,reg.DeptId as DeptId,depart.DeptName as DepartmentName,reg.Details as Details from Regulation reg, Department depart, Employees emp, EmpRoles roles where 
   emp.EmpId = roles.UserId and reg.DeptId = depart.DeptId and emp.DeptId = depart.DeptId and emp.FirstName=@empName and roles.RoleName = @empRole;  
END  
GO

/****** Object:  StoredProcedure [dbo].[UpdateEmployeeDetails]    Script Date: 10/22/2013 12:16:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		COGNIZANT
-- Create date: 05/26/2013
-- Description:	Update Employee details in Employee Db.
-- =============================================
CREATE PROCEDURE [dbo].[UpdateEmployeeDetails] 
@EmpId int,
@firstName varchar(50),
@lastName varchar(50),
@dateOfBirth date,
@email varchar(50),
@phoneNo varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	update Employees 
		set FirstName=@firstName,
		LastName=@lastName,
		DateOfBirth=@dateOfBirth,
		Email=@email,
		PhoneNo=@phoneNo where EmpId=@EmpId;
END

GO

